import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import ProductsPage from './pages/ProductsPage';
import ProductPage from './pages/ProductPage';
import CheckoutPage from './pages/CheckoutPage';
import ContactPage from './pages/ContactPage';
import RefundPolicyPage from './pages/RefundPolicyPage';
import LegalNoticePage from './pages/LegalNoticePage';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage';
import TermsOfServicePage from './pages/TermsOfServicePage';
import { CartProvider } from './context/CartContext';

function App() {
  return (
    <Router>
      <CartProvider>
        <div className="min-h-screen bg-white flex flex-col">
          <Header />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/products" element={<ProductsPage />} />
              <Route path="/product/:productId" element={<ProductPage />} />
              <Route path="/checkout" element={<CheckoutPage />} />
              <Route path="/contact" element={<ContactPage />} />
              <Route path="/refund-policy" element={<RefundPolicyPage />} />
              <Route path="/legal-notice" element={<LegalNoticePage />} />
              <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
              <Route path="/terms-of-service" element={<TermsOfServicePage />} />
            </Routes>
          </main>

          <footer className="bg-[#1f2337] text-white py-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
                <div>
                  <h3 className="text-xl font-bold mb-4">Navigations</h3>
                  <ul className="space-y-2">
                    <li><Link to="/" className="hover:text-gray-300">Home</Link></li>
                    <li><Link to="/products" className="hover:text-gray-300">Catalog</Link></li>
                    <li><Link to="/contact" className="hover:text-gray-300">Contact</Link></li>
                  </ul>
                </div>

                <div>
                  <h3 className="text-xl font-bold mb-4">Does this really work?</h3>
                  <p className="text-gray-300">
                    You don't need to worry about if this is legit or not. We are an official registered business and have a lot of happy customers. We will always do our best to support you on the way of starting a reselling business.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-bold mb-4">Need Help?</h3>
                  <p className="text-gray-300 mb-2">
                    Feel free to contact us by filling out our{' '}
                    <Link to="/contact" className="underline hover:text-white">contact form</Link> or
                    Send us an Email at: info@resell-mansion.com
                  </p>
                  <p className="text-gray-300 mb-2">We Usually answer in between 6-24 hours.</p>
                  <p className="text-gray-300">You can also DM us on social media.</p>
                </div>
              </div>

              <div className="border-t border-gray-700 pt-8">
                <div className="flex flex-col items-center space-y-4">
                  <div className="flex items-center gap-3">
                    <img src="https://www.paypalobjects.com/webstatic/mktg/Logo/pp-logo-100px.png" alt="PayPal" className="h-5" />
                    <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" alt="Visa" className="h-5" />
                    <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="Mastercard" className="h-5" />
                    <img src="https://upload.wikimedia.org/wikipedia/commons/f/fa/American_Express_logo_%282018%29.svg" alt="American Express" className="h-5" />
                  </div>
                  <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-400">
                    <Link to="/terms-of-service" className="hover:text-white">Terms of Service</Link>
                    <span className="text-gray-600">|</span>
                    <Link to="/privacy-policy" className="hover:text-white">Privacy Policy</Link>
                    <span className="text-gray-600">|</span>
                    <Link to="/refund-policy" className="hover:text-white">Refund Policy</Link>
                    <span className="text-gray-600">|</span>
                    <Link to="/legal-notice" className="hover:text-white">Legal Notice</Link>
                  </div>
                  <div className="text-sm text-gray-400">
                    © 2025 Resell-Mansion. All rights reserved.
                  </div>
                </div>
              </div>
            </div>
          </footer>
        </div>
      </CartProvider>
    </Router>
  );
}

export default App;