import React, { useState, useEffect } from 'react';
import { X, ShoppingBag, Truck, Minus, Plus, Trash2 } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useNavigate } from 'react-router-dom';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Cart({ isOpen, onClose }: CartProps) {
  const { items, removeFromCart, updateQuantity, totalPrice } = useCart();
  const [timeLeft, setTimeLeft] = useState(210); // 3:30 minutes in seconds
  const FREE_SHIPPING_THRESHOLD = 50;
  const amountToFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD - totalPrice);
  const navigate = useNavigate();

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isOpen && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isOpen, timeLeft]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
  };

  const handleCheckout = () => {
    onClose();
    navigate('/checkout');
  };

  if (!isOpen) return null;

  const progressPercentage = Math.min((totalPrice / FREE_SHIPPING_THRESHOLD) * 100, 100);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" onClick={(e) => {
      if (e.target === e.currentTarget) onClose();
    }}>
      <div className="absolute inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
      
      <div className="fixed inset-y-0 right-0 flex max-w-full pl-10">
        <div className="w-screen max-w-md transform transition ease-in-out duration-500">
          <div className="flex h-full flex-col overflow-y-scroll bg-white shadow-xl">
            <div className="flex items-center justify-between px-4 py-6 sm:px-6 bg-navy-900 text-white">
              <h2 className="text-lg font-medium">Cart reserved for {formatTime(timeLeft)}</h2>
              <button
                type="button"
                className="text-white hover:text-gray-200"
                onClick={onClose}
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            {/* Free shipping progress */}
            {amountToFreeShipping > 0 && (
              <div className="px-4 py-3 bg-gray-50">
                <div className="flex items-center gap-2 mb-2">
                  <Truck className="h-5 w-5 text-navy-900" />
                  <p className="text-sm text-gray-700">
                    You're €{amountToFreeShipping.toFixed(2)} away from free shipping!
                  </p>
                </div>
                <div className="h-2 bg-gray-200 rounded-full">
                  <div 
                    className="h-full bg-navy-900 rounded-full transition-all duration-300"
                    style={{ width: `${progressPercentage}%` }}
                  />
                </div>
              </div>
            )}

            {items.length === 0 ? (
              <div className="flex-1 px-4 py-6 sm:px-6">
                <div className="flex flex-col items-center justify-center h-full">
                  <ShoppingBag className="h-12 w-12 text-gray-400" />
                  <p className="mt-4 text-gray-500">Your cart is empty</p>
                </div>
              </div>
            ) : (
              <>
                <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-6">
                  <div className="flow-root">
                    <ul className="-my-6 divide-y divide-gray-200">
                      {items.map((item) => (
                        <li key={item.id} className="py-6">
                          <div className="flex items-center">
                            <img
                              src={item.image}
                              alt={item.title}
                              className="h-20 w-20 flex-shrink-0 rounded-md object-contain"
                            />
                            <div className="ml-4 flex flex-1 flex-col">
                              <div>
                                <div className="flex justify-between text-base font-medium text-gray-900">
                                  <h3>{item.title}</h3>
                                  <p className="ml-4">€{item.price.toFixed(2)}</p>
                                </div>
                              </div>
                              <div className="flex items-center justify-between mt-4">
                                <div className="flex items-center border rounded-md">
                                  <button
                                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                    className="p-2 hover:bg-gray-100"
                                    disabled={item.quantity <= 1}
                                  >
                                    <Minus className="h-4 w-4" />
                                  </button>
                                  <span className="px-4 py-2 text-gray-900">{item.quantity}</span>
                                  <button
                                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                    className="p-2 hover:bg-gray-100"
                                    disabled={item.quantity >= 10}
                                  >
                                    <Plus className="h-4 w-4" />
                                  </button>
                                </div>
                                <button
                                  onClick={() => removeFromCart(item.id)}
                                  className="text-gray-400 hover:text-gray-500"
                                >
                                  <Trash2 className="h-5 w-5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="border-t border-gray-200 px-4 py-6 sm:px-6">
                  <div className="flex justify-between text-base font-medium text-gray-900 mb-4">
                    <p>Subtotal</p>
                    <p>€{totalPrice.toFixed(2)}</p>
                  </div>
                  
                  <div className="rounded-md bg-gray-50 p-4 mb-4">
                    <div className="flex">
                      <input
                        type="text"
                        placeholder="Discount code"
                        className="min-w-0 flex-1 rounded-l-md border border-gray-300 px-4 py-2 focus:border-navy-500 focus:ring-navy-500"
                      />
                      <button className="rounded-r-md border border-l-0 border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
                        Apply
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={handleCheckout}
                    className="w-full rounded-md bg-navy-900 px-6 py-3 text-base font-medium text-white shadow-sm hover:bg-navy-800"
                  >
                    Check out
                  </button>

                  <div className="mt-4 text-center">
                    <button
                      type="button"
                      className="text-sm font-medium text-navy-900 hover:text-navy-800"
                      onClick={onClose}
                    >
                      Continue Shopping
                      <span aria-hidden="true"> →</span>
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}