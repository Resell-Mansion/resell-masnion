import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, Menu, X, User } from 'lucide-react';
import { useCart } from '../context/CartContext';
import Cart from './Cart';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { totalItems, isCartOpen, setIsCartOpen } = useCart();
  const [bannerIndex, setBannerIndex] = useState(0);

  const bannerMessages = [
    "🔥 50% OFF Everything - Limited Time →",
    "❤️ 5000+ Happy Customers →"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setBannerIndex((current) => (current + 1) % bannerMessages.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <div className="w-full bg-navy-900 p-2">
        <div className="max-w-7xl mx-auto text-center">
          <Link 
            to="/products" 
            className="text-white text-sm font-medium hover:text-gray-200 inline-block transition-opacity duration-500"
          >
            {bannerMessages[bannerIndex]}
          </Link>
        </div>
      </div>
      <header className="bg-white relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex-1 flex items-center justify-start lg:justify-center">
              <button 
                className="lg:hidden text-gray-700 hover:text-gray-900"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>

              <nav className="hidden lg:flex items-center space-x-8">
                <Link to="/" className="text-gray-700 hover:text-gray-900 hover:bg-gray-100 px-3 py-2 rounded-md transition-colors">Home</Link>
                <Link to="/products" className="text-gray-700 hover:text-gray-900 hover:bg-gray-100 px-3 py-2 rounded-md transition-colors">Products</Link>
                <Link to="/contact" className="text-gray-700 hover:text-gray-900 hover:bg-gray-100 px-3 py-2 rounded-md transition-colors">Contact</Link>
              </nav>
            </div>

            <div className="flex-1 flex justify-center">
              <Link to="/" className="flex-shrink-0">
                <h1 className="text-2xl sm:text-3xl font-serif">Resell-Mansion</h1>
              </Link>
            </div>

            <div className="flex-1 flex items-center justify-end space-x-4 sm:space-x-6">
              <button className="text-gray-700 hover:text-gray-900">
                <Search className="h-5 w-5 sm:h-6 sm:w-6" />
              </button>
              <button 
                className="text-gray-700 hover:text-gray-900 relative"
                onClick={() => setIsCartOpen(true)}
              >
                <div className="relative">
                  <svg 
                    viewBox="0 0 24 24" 
                    className="h-5 w-5 sm:h-6 sm:w-6"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.5"
                  >
                    <path d="M6 8h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2z" />
                    <path d="M8 8V6a4 4 0 0 1 8 0v2" />
                  </svg>
                  {totalItems > 0 && (
                    <div className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center">
                      <div className="absolute inset-0 bg-navy-900 rounded-full"></div>
                      <span className="relative text-xs text-white font-medium">
                        {totalItems}
                      </span>
                    </div>
                  )}
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="lg:hidden fixed inset-0 bg-[#1f2337] z-50">
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between px-4 h-16 bg-white">
                <button 
                  onClick={() => setIsMenuOpen(false)}
                  className="text-gray-700 hover:text-gray-900"
                >
                  <X className="h-6 w-6" />
                </button>
                <Link to="/" className="flex-shrink-0">
                  <h1 className="text-2xl sm:text-3xl font-serif">Resell-Mansion</h1>
                </Link>
                <div className="w-6"></div>
              </div>

              <nav className="flex-1 flex flex-col px-4 py-8 space-y-6">
                <Link 
                  to="/" 
                  className="text-white text-xl font-medium hover:bg-white/10 px-4 py-2 rounded-lg transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Home
                </Link>
                <Link 
                  to="/products" 
                  className="text-white text-xl font-medium hover:bg-white/10 px-4 py-2 rounded-lg transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Products
                </Link>
                <Link 
                  to="/contact" 
                  className="text-white text-xl font-medium hover:bg-white/10 px-4 py-2 rounded-lg transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Contact
                </Link>
              </nav>

              <div className="px-4 py-6 border-t border-gray-700">
                <button className="w-full flex items-center justify-center gap-2 text-white text-xl font-medium">
                  <User className="h-6 w-6" />
                  Log in
                </button>
              </div>
            </div>
          </div>
        )}

        <Cart isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      </header>
    </>
  );
}