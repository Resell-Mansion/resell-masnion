import React from 'react';

export default function Hero() {
  return (
    <div className="relative">
      <div className="absolute inset-0">
        <img
          className="h-full w-full object-cover"
          src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
          alt="Store hero"
        />
        <div className="absolute inset-0 bg-gray-600 mix-blend-multiply" />
      </div>
      <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
          New Collection
        </h1>
        <p className="mt-6 text-xl text-gray-300 max-w-3xl">
          Discover our latest arrivals and trending items. Shop the most stylish and contemporary pieces for your wardrobe.
        </p>
        <div className="mt-10">
          <a
            href="#"
            className="inline-block bg-white py-3 px-8 rounded-md text-base font-medium text-gray-900 hover:bg-gray-100"
          >
            Shop Now
          </a>
        </div>
      </div>
    </div>
  );
}