import React from 'react';
import { Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

interface ProductCardProps {
  id: number;
  image: string;
  title: string;
  price: number;
  category: string;
}

export default function ProductCard({ id, image, title, price, category }: ProductCardProps) {
  const { addToCart } = useCart();

  // Calculate original price and discount
  const getOriginalPrice = () => {
    const markupPercentage = (() => {
      if (title.toLowerCase().includes('guide')) return 50;
      if (title.toLowerCase().includes('bundle')) return 75;
      if (category === 'Electronics') return 40;
      if (category === 'Footwear') return 45;
      if (category === 'Fragrance') return 50;
      return 40;
    })();
    return Number((price / (1 - markupPercentage / 100)).toFixed(2));
  };

  const originalPrice = getOriginalPrice();
  const discountPercentage = Math.round(((originalPrice - price) / originalPrice) * 100);

  const getRating = () => {
    if (title.toLowerCase().includes('guide')) return 5;
    if (category === 'Electronics') return 4;
    if (category === 'Footwear') return 3;
    if (category === 'Bundle') return 5;
    if (category === 'Tools') return 4;
    return 4;
  };

  const getReviewCount = () => {
    if (title.toLowerCase().includes('guide')) return 847;
    if (category === 'Electronics') return Math.floor(Math.random() * (500 - 200) + 200);
    if (category === 'Footwear') return Math.floor(Math.random() * (300 - 100) + 100);
    if (category === 'Bundle') return 642;
    if (category === 'Tools') return 235;
    return Math.floor(Math.random() * (400 - 150) + 150);
  };

  const rating = getRating();
  const reviewCount = getReviewCount();
  const maxRating = 5;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent navigation when clicking the button
    addToCart({
      id,
      title,
      price,
      image,
      quantity: 1
    });
  };

  return (
    <div className="group h-full flex flex-col">
      <Link to={`/product/${id}`} className="flex-grow">
        <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-lg bg-gray-100 relative">
          <div className="w-full h-full">
            <img
              src={image}
              alt={title}
              className="h-full w-full object-contain object-center group-hover:opacity-75 transition-opacity"
            />
          </div>
          <div className="absolute bottom-2 left-2">
            <div className="bg-[#1f2337] text-white px-2 py-1 text-xs font-bold rounded">
              SAVE {discountPercentage}%
            </div>
          </div>
        </div>
        <div className="mt-6 flex flex-col flex-grow">
          <p className="text-sm text-gray-500">{category}</p>
          <h3 className="mt-1 text-lg font-medium text-gray-900">{title}</h3>
          <div className="mt-1 flex items-center">
            {[...Array(maxRating)].map((_, index) => (
              <Star
                key={index}
                className={`w-4 h-4 ${
                  index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                }`}
              />
            ))}
            <span className="ml-2 text-sm text-gray-500">{rating}.0 ({reviewCount})</span>
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-lg font-semibold text-navy-900">€{price.toFixed(2)}</span>
            <span className="text-sm text-gray-500 line-through">€{originalPrice.toFixed(2)}</span>
          </div>
          <p className="text-xs text-gray-500">Tax included</p>
        </div>
      </Link>
      <div className="mt-4">
        <button 
          onClick={handleAddToCart}
          className="w-full bg-navy-900 text-white py-3 rounded-md hover:bg-navy-800 transition-colors"
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}