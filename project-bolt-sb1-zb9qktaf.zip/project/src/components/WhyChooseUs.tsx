import React from 'react';
import { Rocket, Diamond, Lock, Trophy, Users, Clock } from 'lucide-react';

export default function WhyChooseUs() {
  return (
    <div className="bg-gray-50 py-16 sm:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl font-bold text-[#2B2D42] mb-6">Why Choose Us?</h2>
          <p className="text-lg text-gray-600">
            At Resell-Mansion, we pride ourselves on delivering an exceptional experience that sets us apart from the competition.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-xl shadow-sm">
            <div className="flex items-center justify-center w-12 h-12 bg-blue-50 rounded-lg mb-6">
              <Rocket className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-[#2B2D42] mb-4">Fast Shipping</h3>
            <p className="text-gray-600">
              We understand that your time is valuable. That's why we ensure quick and reliable delivery straight to your doorstep. No long waits, no hassle—just what you ordered, when you need it.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-sm">
            <div className="flex items-center justify-center w-12 h-12 bg-purple-50 rounded-lg mb-6">
              <Diamond className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-xl font-bold text-[#2B2D42] mb-4">Top-Quality Products</h3>
            <p className="text-gray-600">
              Quality is at the core of what we offer. Every product is carefully crafted and inspected to meet the highest standards. With us, you don't just get products—you get lasting value and performance.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-sm">
            <div className="flex items-center justify-center w-12 h-12 bg-green-50 rounded-lg mb-6">
              <Lock className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-xl font-bold text-[#2B2D42] mb-4">Secure Payments</h3>
            <p className="text-gray-600">
              Your trust is everything. Our advanced, secure payment systems ensure that your personal and financial information is always protected. Shop with confidence and peace of mind.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-sm">
            <div className="flex items-center justify-center w-12 h-12 bg-red-50 rounded-lg mb-6">
              <Trophy className="w-6 h-6 text-red-600" />
            </div>
            <h3 className="text-xl font-bold text-[#2B2D42] mb-4">Industry Leaders</h3>
            <p className="text-gray-600">
              With years of experience and a proven track record, we've established ourselves as leaders in the reselling industry. Our expertise ensures you get the best guidance and products.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-sm">
            <div className="flex items-center justify-center w-12 h-12 bg-yellow-50 rounded-lg mb-6">
              <Users className="w-6 h-6 text-yellow-600" />
            </div>
            <h3 className="text-xl font-bold text-[#2B2D42] mb-4">Community Support</h3>
            <p className="text-gray-600">
              Join a thriving community of successful resellers. Share experiences, get tips, and grow your business with like-minded entrepreneurs who trust Resell-Mansion.
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-sm">
            <div className="flex items-center justify-center w-12 h-12 bg-indigo-50 rounded-lg mb-6">
              <Clock className="w-6 h-6 text-indigo-600" />
            </div>
            <h3 className="text-xl font-bold text-[#2B2D42] mb-4">24/7 Availability</h3>
            <p className="text-gray-600">
              Our digital platform is always open, allowing you to browse, purchase, and access your products whenever it's convenient for you. Success doesn't wait, and neither should you.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}