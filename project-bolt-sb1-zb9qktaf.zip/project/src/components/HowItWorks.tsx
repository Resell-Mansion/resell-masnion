import React from 'react';
import { Check, Globe, Store } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function HowItWorks() {
  return (
    <div className="py-12 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl sm:text-5xl font-bold text-center text-[#2B2D42] mb-12 sm:mb-20">How does it Work?</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-12 mb-12 sm:mb-16">
          <div className="text-center px-4">
            <div className="flex justify-center mb-6">
              <Check className="w-12 h-12 sm:w-16 sm:h-16 text-navy-900" />
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-[#2B2D42] mb-3 sm:mb-4">Confirm Order</h3>
            <p className="text-sm sm:text-base text-gray-600">
              Set an Order on our Website to receive the vendor and get your replicated items from the vendor.
            </p>
          </div>

          <div className="text-center px-4">
            <div className="flex justify-center mb-6">
              <Globe className="w-12 h-12 sm:w-16 sm:h-16 text-navy-900" />
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-[#2B2D42] mb-3 sm:mb-4">Ship or Meet-up</h3>
            <p className="text-sm sm:text-base text-gray-600">
              From now on if a customer buys either ship through your local post office or meet up and sell your Item.
            </p>
          </div>

          <div className="text-center px-4">
            <div className="flex justify-center mb-6">
              <Store className="w-12 h-12 sm:w-16 sm:h-16 text-navy-900" />
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-[#2B2D42] mb-3 sm:mb-4">Sell on marketplaces like:</h3>
            <p className="text-sm sm:text-base text-gray-600">
              After you have received your 1:1 Products list them on marketplaces like: Ebay, Offerup, Craigslist, Facebook Marketplace.
            </p>
          </div>
        </div>

        <div className="text-center">
          <Link
            to="/products"
            className="inline-block px-6 sm:px-8 py-3 sm:py-4 bg-navy-900 text-white rounded-lg hover:bg-navy-800 transition-colors"
          >
            Take Your First Step
          </Link>
        </div>
      </div>
    </div>
  );
}