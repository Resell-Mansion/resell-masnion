import React, { useState } from 'react';
import { Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Product {
  id: number;
  title: string;
  originalPrice: number;
  price: number;
  discount: number;
  image: string;
}

const products: Product[] = [
  {
    id: 1,
    title: "1:1 Reselling Guide",
    originalPrice: 59.99,
    price: 39.99,
    discount: 33,
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/58E2725B-2EFF-4C88-98B4-C71144BFFFF9.png?v=1736162881"
  },
  {
    id: 2,
    title: "Airforce 1 Vendor",
    originalPrice: 22.95,
    price: 17.95,
    discount: 22,
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/5375_618cee3da69a25.11590256_CW2288-111-2.webp?v=1736162909"
  },
  {
    id: 3,
    title: "AirPods Max Vendor",
    originalPrice: 44.95,
    price: 24.95,
    discount: 44,
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/dbcelx0cxdieuxn7vr1m.png?v=1736162915"
  },
  {
    id: 4,
    title: "AirPods Pro 2 Vendor",
    originalPrice: 49.95,
    price: 29.95,
    discount: 40,
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/AirPods_Pro_2nd_Gen_with_USB-C_PDP_Image_Position-1__en-UScopy.webp?v=1736162912"
  }
];

export default function ProductSlider() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const navigate = useNavigate();

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === products.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? products.length - 1 : prevIndex - 1
    );
  };

  const handleProductClick = () => {
    navigate('/products');
  };

  return (
    <div className="relative overflow-hidden mt-4">
      <div className="relative h-[500px] sm:h-[600px] w-full">
        <div 
          className="absolute w-full h-full flex transition-transform duration-500 ease-out"
          style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        >
          {products.map((product) => (
            <div 
              key={product.id} 
              className="min-w-full h-full flex flex-col items-center justify-center p-4 cursor-pointer"
              onClick={handleProductClick}
            >
              <div className="relative w-full max-w-md">
                <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-lg bg-gray-100 hover:opacity-90 transition-opacity">
                  <div className="absolute bottom-2 left-2 z-10">
                    <div className="bg-[#1f2337] text-white px-3 py-1 text-sm font-bold rounded">
                      SAVE {product.discount}%
                    </div>
                  </div>
                  <img
                    src={product.image}
                    alt={product.title}
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="mt-4 text-center">
                  <h3 className="text-2xl font-medium text-[#2B2D42]">{product.title}</h3>
                  <div className="mt-2 flex items-center justify-center space-x-4">
                    <span className="text-sm text-gray-500 line-through">€{product.originalPrice.toFixed(2)}</span>
                    <span className="text-xl font-bold text-[#2B2D42]">€{product.price.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 bg-white p-2 rounded-full shadow-lg hover:bg-gray-100 z-10"
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
      </button>

      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 bg-white p-2 rounded-full shadow-lg hover:bg-gray-100 z-10"
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
      </button>

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2 z-10">
        {products.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-2 h-2 rounded-full transition-colors ${
              index === currentIndex ? 'bg-[#2B2D42]' : 'bg-gray-300'
            }`}
          />
        ))}
      </div>
    </div>
  );
}