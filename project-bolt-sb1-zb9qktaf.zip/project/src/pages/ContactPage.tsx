import React, { useEffect } from 'react';

export default function ContactPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
        <div className="border-t border-gray-200"></div>
      </div>
      
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-4xl sm:text-5xl font-bold text-[#2B2D42] mb-4 text-center">Contact</h1>
        
        <form className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <input
                type="text"
                name="name"
                placeholder="Name"
                className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:border-[#2B2D42] focus:ring-0 transition-colors"
              />
            </div>

            <div>
              <input
                type="email"
                name="email"
                placeholder="Email *"
                required
                className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:border-[#2B2D42] focus:ring-0 transition-colors"
              />
            </div>
          </div>

          <div>
            <input
              type="tel"
              name="phone"
              placeholder="Phone number"
              className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:border-[#2B2D42] focus:ring-0 transition-colors"
            />
          </div>

          <div>
            <textarea
              name="comment"
              placeholder="Comment"
              rows={6}
              className="w-full px-4 py-2 rounded-lg border border-gray-200 focus:border-[#2B2D42] focus:ring-0 transition-colors"
            />
          </div>

          <div className="flex justify-center">
            <button
              type="submit"
              className="px-12 py-2 bg-[#2B2D42] text-white rounded-lg hover:bg-navy-800 transition-colors"
            >
              Send
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}