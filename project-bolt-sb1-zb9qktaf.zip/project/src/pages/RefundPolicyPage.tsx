import React, { useEffect } from 'react';

export default function RefundPolicyPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
        <div className="border-t border-gray-200"></div>
      </div>
      
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-4xl sm:text-5xl font-bold text-[#2B2D42] text-center mb-8">Refund Policy</h1>
        
        <div className="space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">No Refund Policy for Digital Products</h2>
            <p className="text-gray-600 leading-relaxed">
              Due to the nature of our products being digital and delivered instantly via email after purchase, 
              we maintain a strict no refund policy. All sales are final once the digital product has been delivered.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">Why We Don't Offer Refunds</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Our products are digital goods that are delivered instantly</li>
              <li>You receive immediate access to the purchased content via email</li>
              <li>Digital products cannot be "returned" once they have been delivered</li>
              <li>This policy helps us maintain fair pricing and prevent misuse</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">Before Making a Purchase</h2>
            <p className="text-gray-600 mb-3">We encourage all customers to:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Carefully read the product description</li>
              <li>Review all product details and requirements</li>
              <li>Contact us with any questions before purchasing</li>
              <li>Ensure the product meets your needs</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">Delivery Confirmation</h2>
            <p className="text-gray-600 mb-3">Upon successful payment:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Digital products are delivered immediately via email</li>
              <li>Delivery is considered complete when the email is sent</li>
              <li>Please ensure your email address is correct during checkout</li>
              <li>Check your spam folder if you don't see the delivery email</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">Technical Support</h2>
            <p className="text-gray-600 mb-3">While we don't offer refunds, we do provide:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Technical support for accessing your digital products</li>
              <li>Assistance with download or delivery issues</li>
              <li>Help with product usage questions</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">Contact Us</h2>
            <p className="text-gray-600 leading-relaxed">
              If you experience any technical issues with delivery or access to your digital product, 
              please contact us immediately through our contact page. We will assist you in resolving 
              any technical problems.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}