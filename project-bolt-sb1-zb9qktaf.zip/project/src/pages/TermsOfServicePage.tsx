import React, { useEffect } from 'react';

export default function TermsOfServicePage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
        <div className="border-t border-gray-200"></div>
      </div>
      
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-4xl sm:text-5xl font-bold text-[#2B2D42] text-center mb-8">Terms of Service</h1>
        
        <div className="space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">1. Acceptance of Terms</h2>
            <p className="text-gray-600 leading-relaxed">
              By accessing and using this website, you accept and agree to be bound by the terms and provision of this agreement.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">2. Digital Products</h2>
            <p className="text-gray-600 leading-relaxed">
              All products sold on Resell Mansion are digital products. Upon successful payment, products will be delivered instantly via email to the address provided during checkout.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">3. Product Usage</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Products are for personal use only</li>
              <li>Redistribution or resale of our products is strictly prohibited</li>
              <li>Each purchase grants a single-user license</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">4. Delivery</h2>
            <p className="text-gray-600 leading-relaxed">
              Digital products are delivered automatically via email immediately after successful payment processing. It is the customer's responsibility to ensure the correct email address is provided during checkout.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">5. Pricing and Payment</h2>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>All prices are listed in EUR</li>
              <li>Prices may change without notice</li>
              <li>All payments are processed securely through Mollie payment services</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">6. Intellectual Property</h2>
            <p className="text-gray-600 leading-relaxed">
              All content on this website, including but not limited to text, graphics, logos, and software, is the property of Resell Mansion and is protected by copyright laws.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">7. User Obligations</h2>
            <p className="text-gray-600 mb-3">Users agree to:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Provide accurate and complete information during purchase</li>
              <li>Use the website for lawful purposes only</li>
              <li>Not attempt to circumvent any security measures</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">8. Disclaimer</h2>
            <p className="text-gray-600 leading-relaxed">
              Resell Mansion provides its services "as is" and makes no warranties, expressed or implied, and hereby disclaims all warranties, including without limitation.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">9. Limitation of Liability</h2>
            <p className="text-gray-600 leading-relaxed">
              Resell Mansion shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of our services.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">10. Changes to Terms</h2>
            <p className="text-gray-600 leading-relaxed">
              We reserve the right to modify these terms at any time. Changes will be effective immediately upon posting to the website.
            </p>
          
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">11. Contact Information</h2>
            <p className="text-gray-600 leading-relaxed">
              For any questions regarding these terms, please contact us through our contact page.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}