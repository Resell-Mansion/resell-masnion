import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { Lock, CreditCard } from 'lucide-react';

export default function CheckoutPage() {
  const { items, totalPrice } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo(0, 0);
    
    // Redirect to products if cart is empty
    if (items.length === 0) {
      navigate('/products');
    }
  }, [items, navigate]);

  if (items.length === 0) {
    return null;
  }

  return (
    <div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
        <div className="border-t border-gray-200"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-x-12 gap-y-8">
          {/* Checkout Form */}
          <div>
            <h2 className="text-2xl font-bold mb-8">Checkout</h2>
            
            <div className="space-y-6">
              {/* Contact Information */}
              <div>
                <h3 className="text-lg font-medium mb-4">Contact Information</h3>
                <div className="space-y-4">
                  <input
                    type="email"
                    placeholder="Email"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-navy-500 focus:border-navy-500"
                  />
                </div>
              </div>

              {/* Billing Information */}
              <div>
                <h3 className="text-lg font-medium mb-4">Billing Information</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      type="text"
                      placeholder="First name"
                      className="px-4 py-2 border border-gray-300 rounded-md focus:ring-navy-500 focus:border-navy-500"
                    />
                    <input
                      type="text"
                      placeholder="Last name"
                      className="px-4 py-2 border border-gray-300 rounded-md focus:ring-navy-500 focus:border-navy-500"
                    />
                  </div>
                  <input
                    type="text"
                    placeholder="Address"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-navy-500 focus:border-navy-500"
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      type="text"
                      placeholder="City"
                      className="px-4 py-2 border border-gray-300 rounded-md focus:ring-navy-500 focus:border-navy-500"
                    />
                    <input
                      type="text"
                      placeholder="Postal code"
                      className="px-4 py-2 border border-gray-300 rounded-md focus:ring-navy-500 focus:border-navy-500"
                    />
                  </div>
                  <input
                    type="text"
                    placeholder="Country"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-navy-500 focus:border-navy-500"
                  />
                </div>
              </div>

              {/* Payment Information */}
              <div>
                <h3 className="text-lg font-medium mb-4">Payment Information</h3>
                <div className="space-y-4">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Card number"
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-navy-500 focus:border-navy-500"
                    />
                    <CreditCard className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      type="text"
                      placeholder="MM/YY"
                      className="px-4 py-2 border border-gray-300 rounded-md focus:ring-navy-500 focus:border-navy-500"
                    />
                    <input
                      type="text"
                      placeholder="CVC"
                      className="px-4 py-2 border border-gray-300 rounded-md focus:ring-navy-500 focus:border-navy-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div>
            <div className="bg-gray-50 rounded-lg p-6 sticky top-6">
              <h3 className="text-lg font-medium mb-4">Order Summary</h3>
              
              <div className="divide-y divide-gray-200">
                {items.map((item) => (
                  <div key={item.id} className="py-4 flex items-center">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="h-16 w-16 rounded object-contain"
                    />
                    <div className="ml-4 flex-1">
                      <h4 className="text-sm font-medium">{item.title}</h4>
                      <p className="text-sm text-gray-500">Quantity: {item.quantity}</p>
                    </div>
                    <p className="text-sm font-medium">€{(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                ))}
              </div>

              <div className="mt-6 space-y-2">
                <div className="flex justify-between text-sm">
                  <p>Subtotal</p>
                  <p>€{totalPrice.toFixed(2)}</p>
                </div>
                <div className="flex justify-between text-sm">
                  <p>Shipping</p>
                  <p>{totalPrice >= 50 ? 'Free' : '€4.95'}</p>
                </div>
                <div className="flex justify-between text-sm font-medium">
                  <p>Total</p>
                  <p>€{(totalPrice + (totalPrice >= 50 ? 0 : 4.95)).toFixed(2)}</p>
                </div>
              </div>

              <button className="mt-6 w-full bg-navy-900 text-white py-3 rounded-md hover:bg-navy-800 transition-colors flex items-center justify-center">
                <Lock className="h-4 w-4 mr-2" />
                Complete Order
              </button>

              <p className="mt-4 text-xs text-gray-500 text-center">
                Your payment information is encrypted and secure. We never store your credit card details.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}