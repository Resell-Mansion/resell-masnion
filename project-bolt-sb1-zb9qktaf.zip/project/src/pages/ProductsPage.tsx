import React, { useEffect } from 'react';
import ProductCard from '../components/ProductCard';

export const allProducts = [
  {
    id: 1,
    title: "1:1 Reselling Guide",
    price: 39.99,
    category: "Guide",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/58E2725B-2EFF-4C88-98B4-C71144BFFFF9.png?v=1736162881"
  },
  {
    id: 2,
    title: "iPhone 15 Vendor",
    price: 79.99,
    category: "Electronics",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/Final_iPhone-14-Pro-Split-Full-Wrap-Vinyl-Skin-Design-Mockup-Front-Back-Angled-View_7c8b1dba-0ddc-4f69-b26e-160550b46b97.webp?v=1736162977"
  },
  {
    id: 3,
    title: "AirPods Pro 2 Vendor",
    price: 29.95,
    category: "Electronics",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/AirPods_Pro_2nd_Gen_with_USB-C_PDP_Image_Position-1__en-UScopy.webp?v=1736162912"
  },
  {
    id: 4,
    title: "AirPods Max Vendor",
    price: 24.95,
    category: "Electronics",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/dbcelx0cxdieuxn7vr1m.png?v=1736162915"
  },
  {
    id: 5,
    title: "Apple Watch Ultra Vendor",
    price: 21.95,
    category: "Electronics",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/Apple_Watch_Ultra_Titanium_dff179dc-e883-490b-9c33-8c93201b1c9b.webp?v=1736162919"
  },
  {
    id: 6,
    title: "Samsung S23 Ultra Vendor",
    price: 84.99,
    category: "Electronics",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/full_body_housing_for_samsung_galaxy_s23_ultra_black_maxbhi_com_54246.jpg?v=1736162965"
  },
  {
    id: 7,
    title: "Galaxy Buds Vendor",
    price: 29.95,
    category: "Electronics",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/Samsung-Galaxy-Buds-Pro-Silver-1_1.png?v=1736162960"
  },
  {
    id: 8,
    title: "JBL Pulse 5 Vendor",
    price: 17.95,
    category: "Electronics",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/1_JBL_PULSE_5_HERO_34364_x2_406d3d40-68f9-4482-a929-ba5cf1d5b3d0.webp?v=1736162937"
  },
  {
    id: 9,
    title: "JBL Flip 6 Vendor",
    price: 19.95,
    category: "Electronics",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/6_JBL_FLIP_6_3_4_LEFT_BLACK_x1-500x500-1.png?v=1736162934"
  },
  {
    id: 10,
    title: "JBL Charge 5 Vendor",
    price: 19.95,
    category: "Electronics",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/JBL_CHARGE5_HERO_BLACK_0046_x1_55e1907d-f60e-4c12-8585-cded54424f28.webp?v=1736162928"
  },
  {
    id: 11,
    title: "Nike Air Force 1 Vendor",
    price: 17.95,
    category: "Footwear",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/5375_618cee3da69a25.11590256_CW2288-111-2.webp?v=1736162909"
  },
  {
    id: 12,
    title: "Jordan 1 Vendor",
    price: 17.95,
    category: "Footwear",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/DesignohneTitel-2023-04-17T143851.017.webp?v=1736162944"
  },
  {
    id: 13,
    title: "Wolkis Vendor",
    price: 19.95,
    category: "Footwear",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/Bildschirmfoto_2024-03-08_um_19.50.43-removebg-preview.png?v=1736162987"
  },
  {
    id: 14,
    title: "Moncler Maya Jacket Vendor",
    price: 49.99,
    category: "Clothing",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/07e84d_6d869f53bc43432a820d01b544d5a46b_mv2.webp?v=1736162953"
  },
  {
    id: 15,
    title: "Belstaff Jacket Vendor",
    price: 49.95,
    category: "Clothing",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/FullSizeRender.jpg?v=1736162891"
  },
  {
    id: 16,
    title: "Tom Ford Tobacco Vanille Vendor",
    price: 34.95,
    category: "Fragrance",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/tf_sku_T01K01_2000x2000_0_2.webp?v=1736162894"
  },
  {
    id: 17,
    title: "Creed Aventus Vendor",
    price: 24.95,
    category: "Fragrance",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/aventus_50_ml_1.webp?v=1736162902"
  },
  {
    id: 18,
    title: "LV Ombre Nomade Vendor",
    price: 29.95,
    category: "Fragrance",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/louis-vuitton-ombre-nomade--LP0096_PM2_Frontview.webp?v=1736162899"
  },
  {
    id: 19,
    title: "Versace Eros Vendor",
    price: 29.95,
    category: "Fragrance",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/versace_eros_flame_eau_de_parfum_spray_30_ml_8011003845330_223573_20240321023458.webp?v=1736162896"
  },
  {
    id: 20,
    title: "LV Belt Vendor",
    price: 12.95,
    category: "Accessories",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/louis-vuitton-lv-initiales-wendegurtel-30-mm--M0565T_PM2_Frontview.webp?v=1736162949"
  },
  {
    id: 21,
    title: "Prada Glasses Vendor",
    price: 15.95,
    category: "Accessories",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/prada-17ws-1ab5s0-49-20.jpg?v=1736162956"
  },
  {
    id: 22,
    title: "Rolex Vendor",
    price: 79.95,
    category: "Accessories",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/FullSizeRender_28cbdb24-7b1f-4392-b44b-be8a902828cc.jpg?v=1736162887"
  },
  {
    id: 23,
    title: "Receipt Generator",
    price: 9.99,
    category: "Tools",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/Download.jpg?v=1736162905"
  },
  {
    id: 24,
    title: "All Vendors Bundle (Save 75%)",
    price: 399.00,
    category: "Bundle",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/Resell-Mansion_4.png?v=1736162981"
  },
  {
    id: 25,
    title: "Dyson Supersonic Dryer Vendor",
    price: 24.95,
    category: "Electronics",
    image: "https://cdn.shopify.com/s/files/1/0929/6694/5107/files/5ba3596ac2971a05b48a15e7.png?v=1736162924"
  },
  {
    id: 26,
    title: "Shure SM7B Vendor",
    price: 29.95,
    category: "Electronics",
    image: "https://products.shureweb.eu/cdn-cgi/image/width=1380,height=1380,format=auto/shure_product_db/product_main_images/files/03c/1c6/a8-/original/44f793db0b8b3ba23c5461e77d1f3adf.webp"
  }
];

export default function ProductsPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
      <div className="border-t border-gray-200"></div>
      <div className="space-y-6 mt-6">
        <div className="space-y-1">
          <h1 className="text-4xl font-extrabold tracking-tight text-[#2B2D42]">
            All Products
          </h1>
          <p className="text-xl text-gray-500">
            Browse our complete collection
          </p>
        </div>

        <div className="grid grid-cols-2 gap-x-6 gap-y-10">
          {allProducts.map((product) => (
            <ProductCard
              key={product.id}
              id={product.id}
              image={product.image}
              title={product.title}
              price={product.price}
              category={product.category}
            />
          ))}
        </div>
      </div>
    </div>
  );
}