import React, { useEffect } from 'react';

export default function PrivacyPolicyPage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
        <div className="border-t border-gray-200"></div>
      </div>
      
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-4xl sm:text-5xl font-bold text-[#2B2D42] text-center mb-8">Privacy Policy</h1>
        
        <div className="space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">1. Information We Collect</h2>
            <p className="text-gray-600 mb-3">We collect the following types of information:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Name and contact information (email, phone number)</li>
              <li>Billing and shipping address</li>
              <li>Payment information (processed securely through Mollie)</li>
              <li>Order history and preferences</li>
              <li>Device information and IP address</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">2. How We Use Your Information</h2>
            <p className="text-gray-600 mb-3">We use your information to:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Process and fulfill your orders</li>
              <li>Send order confirmations and digital product delivery</li>
              <li>Provide customer support</li>
              <li>Improve our website and services</li>
              <li>Send important updates about our services</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">3. Data Security</h2>
            <p className="text-gray-600 mb-3">We implement appropriate security measures to protect your personal information:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Secure payment processing through Mollie</li>
              <li>Encrypted data transmission</li>
              <li>Regular security assessments</li>
              <li>Limited access to personal information</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">4. Cookies and Tracking</h2>
            <p className="text-gray-600 mb-3">We use cookies to:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Remember your cart items</li>
              <li>Improve website performance</li>
              <li>Analyze website traffic</li>
              <li>Enhance user experience</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">5. Third-Party Services</h2>
            <p className="text-gray-600 mb-3">We use trusted third-party services for:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Payment processing (Mollie)</li>
              <li>Email delivery</li>
              <li>Analytics</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">6. Your Rights</h2>
            <p className="text-gray-600 mb-3">You have the right to:</p>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Access your personal information</li>
              <li>Correct inaccurate information</li>
              <li>Request deletion of your information</li>
              <li>Opt-out of marketing communications</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">7. Data Retention</h2>
            <p className="text-gray-600 leading-relaxed">
              We retain your information for as long as necessary to provide our services and comply with legal obligations.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">8. Children's Privacy</h2>
            <p className="text-gray-600 leading-relaxed">
              Our services are not intended for children under 13. We do not knowingly collect information from children under 13.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">9. Changes to Privacy Policy</h2>
            <p className="text-gray-600 leading-relaxed">
              We may update this policy periodically. Changes will be posted on this page with an updated revision date.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">10. Contact Us</h2>
            <p className="text-gray-600 leading-relaxed">
              For privacy-related questions or concerns, please contact us through our contact page.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}