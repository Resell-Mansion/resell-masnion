import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import ProductSlider from '../components/ProductSlider';
import ProductCard from '../components/ProductCard';
import Testimonials from '../components/Testimonials';
import HowItWorks from '../components/HowItWorks';
import WhyChooseUs from '../components/WhyChooseUs';
import { useCart } from '../context/CartContext';

const bestSeller = {
  id: 16,
  title: "Tom Ford Tobacco Vanille Vendor",
  price: 34.95,
  originalPrice: 69.95,
  category: "RESELL-MANSION",
  image: "https://media.douglas.de/medias/O0e2Fj997498-0-global.jpg?context=bWFzdGVyfGltYWdlc3w3MjcyMXxpbWFnZS9qcGVnfGFEY3hMMmhtWWk4eE16TTBOall3TWpNNE5UUXpPQzlQTUdVeVJtbzVPVGMwT1RoZk1GOW5iRzlpWVd3dWFuQm58ZTMzYzY1OWVmMTNkMjAyZjA1NzliZmUxNWYxMTEzODlhZDdiMTA2NzIzMTFjNTM0ZWI2ZTQyOWJiMzI5N2EwYQ&grid=true&imPolicy=grayScaled&imdensity=1&imwidth=775"
};

export default function HomePage() {
  const [quantity, setQuantity] = React.useState(1);
  const [selectedSize, setSelectedSize] = React.useState(50);
  const { addToCart } = useCart();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const incrementQuantity = () => setQuantity(prev => prev + 1);
  const decrementQuantity = () => setQuantity(prev => prev > 1 ? prev - 1 : 1);

  const handleAddToCart = () => {
    addToCart({
      id: bestSeller.id,
      title: bestSeller.title,
      price: bestSeller.price,
      image: bestSeller.image,
      quantity: quantity
    });
  };

  return (
    <div className="bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
        <div className="border-t border-gray-200"></div>
        <div className="text-center max-w-3xl mx-auto px-4 sm:px-0 mt-2 sm:mt-6">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-navy-900 mb-1 sm:mb-2">What do we offer?</h1>
          <div className="space-y-0.5 sm:space-y-1 text-sm sm:text-base md:text-lg text-gray-600">
            <div className="flex flex-col items-center">
              <p className="text-center mb-1">1:1 Product suppliers with original packaging and valid serial numbers.</p>
              <span className="text-lg">✅</span>
            </div>
            <div className="flex flex-col items-center">
              <p className="text-center mb-1">These are the same suppliers we used to build our reselling business.</p>
              <span className="text-lg">✅</span>
            </div>
            <div className="flex flex-col items-center">
              <p className="text-center mb-1">Receive a free reselling tutorial PDF with every purchase.</p>
              <span className="text-lg">✅</span>
            </div>
          </div>
          <Link
            to="/products"
            className="inline-block mt-2 sm:mt-3 px-6 sm:px-8 py-2 sm:py-3 bg-navy-900 text-white rounded-md hover:bg-navy-800 transition-colors text-sm sm:text-base"
          >
            See All Products
          </Link>
        </div>

        <div className="mt-12">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center text-navy-900">Featured Products</h2>
          <ProductSlider />
        </div>

        <div className="mt-2 sm:mt-6">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-center text-navy-900 mb-6">Best Seller</h2>
          <div className="max-w-md mx-auto px-4 sm:px-0">
            <div className="group">
              <div className="aspect-w-1 aspect-h-1 w-full overflow-hidden rounded-lg bg-gray-100">
                <img
                  src={bestSeller.image}
                  alt={bestSeller.title}
                  className="h-full w-full object-contain object-center"
                />
              </div>
              <div className="mt-4">
                <p className="text-sm text-gray-500 tracking-wider">{bestSeller.category}</p>
                <h3 className="mt-1 text-2xl sm:text-3xl font-bold text-[#2B2D42]">{bestSeller.title}</h3>
                <div className="mt-2 flex items-center gap-4">
                  <span className="text-lg text-gray-500 line-through">€{bestSeller.originalPrice.toFixed(2)}</span>
                  <span className="text-2xl font-bold text-[#2B2D42]">€{bestSeller.price.toFixed(2)}</span>
                  <span className="bg-[#2B2D42] text-white px-4 py-2 rounded-full text-sm font-medium">
                    SAVE 50%
                  </span>
                </div>
                <p className="mt-2 text-sm text-gray-500">Tax included.</p>
                <div className="mt-2 sm:mt-3">
                  <p className="text-lg mb-1">Size</p>
                  <div className="flex gap-2">
                    <button 
                      className={`w-16 h-8 border-2 rounded-full text-sm font-medium transition-colors ${
                        selectedSize === 100 
                          ? 'border-[#2B2D42] text-white bg-[#2B2D42]' 
                          : 'border-gray-300 text-gray-700 hover:border-[#2B2D42]'
                      }`}
                      onClick={() => setSelectedSize(100)}
                    >
                      100ml
                    </button>
                    <button 
                      className={`w-16 h-8 border-2 rounded-full text-sm font-medium transition-colors ${
                        selectedSize === 50 
                          ? 'border-[#2B2D42] text-white bg-[#2B2D42]' 
                          : 'border-gray-300 text-gray-700 hover:border-[#2B2D42]'
                      }`}
                      onClick={() => setSelectedSize(50)}
                    >
                      50ml
                    </button>
                    <button 
                      className={`w-16 h-8 border-2 rounded-full text-sm font-medium transition-colors ${
                        selectedSize === 30 
                          ? 'border-[#2B2D42] text-white bg-[#2B2D42]' 
                          : 'border-gray-300 text-gray-700 hover:border-[#2B2D42]'
                      }`}
                      onClick={() => setSelectedSize(30)}
                    >
                      30ml
                    </button>
                  </div>
                </div>
                <div className="mt-2 sm:mt-3">
                  <p className="text-lg mb-1">Quantity</p>
                  <div className="flex border-2 border-gray-300 rounded-lg w-32">
                    <button 
                      onClick={decrementQuantity}
                      className="px-4 py-2 text-gray-500 hover:text-gray-700"
                    >
                      −
                    </button>
                    <input
                      type="number"
                      min="1"
                      value={quantity}
                      className="w-full text-center border-none focus:ring-0"
                      readOnly
                    />
                    <button 
                      onClick={incrementQuantity}
                      className="px-4 py-2 text-gray-500 hover:text-gray-700"
                    >
                      +
                    </button>
                  </div>
                </div>
                <button 
                  onClick={handleAddToCart}
                  className="mt-3 w-full bg-[#2B2D42] text-white py-3 rounded-lg hover:bg-navy-800 transition-colors text-lg font-medium"
                >
                  ADD TO CART
                </button>
              </div>
            </div>
          </div>
        </div>

        <Testimonials />
        <HowItWorks />
        <WhyChooseUs />
      </div>
    </div>
  );
}