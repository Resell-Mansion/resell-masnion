import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Star, Minus, Plus, Package, CheckSquare, Box, FileText, ChevronDown, Check, X } from 'lucide-react';
import { useCart } from '../context/CartContext';
import WhyChooseUs from '../components/WhyChooseUs';

interface Product {
  id: number;
  title: string;
  price: number;
  category: string;
  image: string;
}

interface Review {
  name: string;
  text: string;
  rating: number;
}

const reviews: Review[] = [
  {
    name: "Andrea Q.",
    text: "I was surprised at how quickly my products were shipped!",
    rating: 5
  },
  {
    name: "Michael S.",
    text: "Best quality I've seen so far. Will definitely order again!",
    rating: 5
  },
  {
    name: "Sarah L.",
    text: "Amazing service and fast delivery. Very satisfied!",
    rating: 5
  },
  {
    name: "David R.",
    text: "Exactly what I was looking for. Great communication!",
    rating: 4
  },
  {
    name: "Emma T.",
    text: "Perfect quality and packaging. Highly recommended!",
    rating: 5
  }
];

import { allProducts } from './ProductsPage';

export default function ProductPage() {
  const { productId } = useParams<{ productId: string }>();
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState('Black');
  const [selectedStorage, setSelectedStorage] = useState('128GB');
  const [selectedSize, setSelectedSize] = useState('M');
  const { addToCart } = useCart();
  const [currentTestimonialIndex, setCurrentTestimonialIndex] = useState(0);
  const [viewerCount, setViewerCount] = useState(97);
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const viewerInterval = setInterval(() => {
      const newCount = Math.floor(Math.random() * (150 - 50 + 1)) + 50;
      setViewerCount(newCount);
    }, 3000);

    const reviewInterval = setInterval(() => {
      setCurrentTestimonialIndex((current) => (current + 1) % reviews.length);
    }, 5000);

    return () => {
      clearInterval(viewerInterval);
      clearInterval(reviewInterval);
    };
  }, []);

  const product = allProducts.find(p => p.id === Number(productId));
  const isIPhone = product?.title.toLowerCase().includes('iphone');
  const isSamsung = product?.title.toLowerCase().includes('samsung s23');
  const isMonclerMaya = product?.title.toLowerCase().includes('moncler maya');
  const isBelstaff = product?.title.toLowerCase().includes('belstaff');
  const isJordan = product?.title.toLowerCase().includes('jordan 1');
  const isAirForce = product?.title.toLowerCase().includes('air force 1');
  const isWolkis = product?.title.toLowerCase().includes('wolkis');
  const isFragrance = product?.category === 'Fragrance';

  const colors = isIPhone 
    ? [
        { name: 'Black', class: 'bg-gray-900', price: 0 },
        { name: 'Gray', class: 'bg-gray-400', price: 50 },
        { name: 'Green', class: 'bg-green-500', price: 50 }
      ]
    : isSamsung
    ? [
        { name: 'Black', class: 'bg-gray-900', price: 0 },
        { name: 'Pink', class: 'bg-pink-300', price: 50 }
      ]
    : [];

  const storageOptions = isIPhone 
    ? [
        { size: '128GB', price: 0 },
        { size: '256GB', price: 100 },
        { size: '512GB', price: 200 }
      ]
    : isSamsung
    ? [
        { size: '256GB', price: 0 },
        { size: '512GB', price: 150 },
        { size: '1024GB', price: 300 }
      ]
    : [];

  const sizes = isFragrance
    ? ['30ml', '50ml', '100ml']
    : isMonclerMaya || isBelstaff
    ? ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL']
    : (isJordan || isAirForce || isWolkis)
    ? ['38', '39', '40', '41', '42', '43', '44', '45']
    : [];

  useEffect(() => {
    if (isFragrance) {
      setSelectedSize('50ml');
    }
    if (isIPhone) {
      setSelectedStorage('128GB');
      setSelectedColor('Black');
    }
  }, [isFragrance, isIPhone]);

  const getPriceAdjustment = () => {
    if (!product) return 0;
    let adjustment = 0;

    if (isIPhone) {
      // Color adjustment
      const selectedColorObj = colors.find(c => c.name === selectedColor);
      if (selectedColorObj) {
        adjustment += selectedColorObj.price;
      }

      // Storage adjustment
      const selectedStorageObj = storageOptions.find(s => s.size === selectedStorage);
      if (selectedStorageObj) {
        adjustment += selectedStorageObj.price;
      }
    } else if (isSamsung) {
      // Color adjustment
      const selectedColorObj = colors.find(c => c.name === selectedColor);
      if (selectedColorObj) {
        adjustment += selectedColorObj.price;
      }

      // Storage adjustment
      const selectedStorageObj = storageOptions.find(s => s.size === selectedStorage);
      if (selectedStorageObj) {
        adjustment += selectedStorageObj.price;
      }
    } else if (isFragrance) {
      if (selectedSize === '100ml') adjustment += 10;
      if (selectedSize === '30ml') adjustment -= 5;
    }

    return adjustment;
  };

  const adjustedPrice = product ? product.price + getPriceAdjustment() : 0;

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
        <div className="border-t border-gray-200"></div>
        <div className="text-center py-12">
          <h2 className="text-3xl font-bold text-gray-900">Product not found</h2>
        </div>
      </div>
    );
  }

  const getOriginalPrice = () => {
    const markupPercentage = (() => {
      if (product.title.toLowerCase().includes('guide')) return 50;
      if (product.title.toLowerCase().includes('bundle')) return 75;
      if (product.category === 'Electronics') return 40;
      if (product.category === 'Footwear') return 45;
      if (product.category === 'Fragrance') return 50;
      return 40;
    })();
    return Number((adjustedPrice / (1 - markupPercentage / 100)).toFixed(2));
  };

  const getFrequentlyBoughtTogether = () => {
    if (product.title.toLowerCase().includes('airpods')) {
      return [
        allProducts.find(p => p.title.includes('1:1 Reselling Guide')),
        {
          ...allProducts.find(p => p.title.includes('iPhone 15')),
          variants: ['Black / 128GB', 'Black / 256GB', 'White / 128GB']
        },
        {
          ...allProducts.find(p => p.title.includes('Creed')),
          variants: ['30ml', '50ml', '100ml']
        }
      ].filter(Boolean);
    }
    
    if (product.title.toLowerCase().includes('iphone')) {
      return [
        allProducts.find(p => p.title.includes('1:1 Reselling Guide')),
        allProducts.find(p => p.title.includes('AirPods Pro')),
        {
          ...allProducts.find(p => p.title.includes('Apple Watch')),
          variants: ['Black', 'Silver', 'Gold']
        }
      ].filter(Boolean);
    }

    if (product.category === 'Footwear') {
      return [
        allProducts.find(p => p.title.includes('1:1 Reselling Guide')),
        {
          ...allProducts.find(p => p.title.includes('Jordan 1')),
          variants: ['38', '39', '40', '41', '42', '43', '44', '45']
        },
        {
          ...allProducts.find(p => p.title.includes('Air Force 1')),
          variants: ['38', '39', '40', '41', '42', '43', '44', '45']
        }
      ].filter(Boolean);
    }

    if (product.category === 'Fragrance') {
      return [
        allProducts.find(p => p.title.includes('1:1 Reselling Guide')),
        {
          ...allProducts.find(p => p.title.includes('Creed')),
          variants: ['30ml', '50ml', '100ml']
        },
        {
          ...allProducts.find(p => p.title.includes('Tom Ford')),
          variants: ['30ml', '50ml', '100ml']
        }
      ].filter(Boolean);
    }

    return [
      allProducts.find(p => p.title.includes('1:1 Reselling Guide')),
      {
        ...allProducts.find(p => p.title.includes('iPhone 15')),
        variants: ['Black / 128GB', 'Black / 256GB', 'White / 128GB']
      },
      {
        ...allProducts.find(p => p.title.includes('Creed')),
        variants: ['30ml', '50ml', '100ml']
      }
    ].filter(Boolean);
  };

  const getProductImage = () => {
    if (!isIPhone && !isSamsung) return product?.image;
    
    if (isIPhone) {
      switch (selectedColor) {
        case 'Gray':
          return "https://cdn.shopify.com/s/files/1/0855/1576/4040/files/65038654434d0-iPhone15ProNaturaltitaniumpng.png?v=1729621558";
        case 'Green':
          return "https://cdn.shopify.com/s/files/1/0855/1576/4040/files/iPhone_15_Plus_iPhone_15_Green_Combo_Screen__WWEN_800x_aca2ece5-6db5-4405-ad1f-f1445bdfa772.webp?v=1729621558";
        default:
          return product?.image;
      }
    }
    
    if (isSamsung) {
      switch (selectedColor) {
        case 'Pink':
          return "https://cdn.shopify.com/s/files/1/0855/1576/4040/files/back.png?v=1729621568";
        default:
          return product?.image;
      }
    }
    
    return product?.image;
  };

  const handleAddToCart = () => {
    if (!product) return;
    
    let title = product.title;
    if (isIPhone) {
      title = `${product.title} - ${selectedColor} ${selectedStorage}`;
    } else if (isMonclerMaya || isBelstaff) {
      title = `${product.title} - Size ${selectedSize}`;
    } else if (isJordan || isAirForce || isWolkis) {
      title = `${product.title} - EU ${selectedSize}`;
    } else if (isFragrance) {
      title = `${product.title} - ${selectedSize}`;
    }
    
    addToCart({
      id: product.id,
      title,
      price: adjustedPrice,
      image: product.image,
      quantity: quantity
    });
  };

  const handleAddAllToCart = () => {
    const frequentlyBought = getFrequentlyBoughtTogether();
    frequentlyBought.forEach(item => {
      if (item) {
        addToCart({
          id: item.id,
          title: item.title,
          price: item.price,
          image: item.image,
          quantity: 1
        });
      }
    });
  };

  const frequentlyBought = getFrequentlyBoughtTogether();
  const totalOriginalPrice = frequentlyBought.reduce((sum, item) => sum + (item ? getOriginalPrice() : 0), 0);
  const totalDiscountedPrice = frequentlyBought.reduce((sum, item) => sum + (item ? item.price : 0), 0);
  const totalSavings = totalOriginalPrice - totalDiscountedPrice;

  const originalPrice = getOriginalPrice();
  const discountPercentage = Math.round(((originalPrice - product.price) / originalPrice) * 100);

  const faqs = [
    {
      id: 'how-cheap',
      question: 'How is this product so cheap?',
      answer: 'We work directly with manufacturers and maintain strong relationships with suppliers, allowing us to offer premium products at significantly reduced prices. By cutting out middlemen and operating efficiently, we pass these savings directly to our customers.'
    },
    {
      id: 'after-purchase',
      question: 'What happens after I purchase?',
      answer: 'After your purchase, you\'ll receive an immediate email confirmation with your order details. Within 24 hours, you\'ll receive another email containing your product access information and comprehensive instructions.'
    }
  ];

  const toggleFaq = (id: string) => {
    setExpandedFaq(expandedFaq === id ? null : id);
  };

  const currentReview = reviews[currentTestimonialIndex];

  return (
    <div className="bg-white">
      <div className="relative">
        <div className="absolute top-0 left-0 right-0 bg-red-600 text-white text-center py-2">
          <h2 className="text-sm font-bold tracking-wider">HOT PRODUCT | LOW STOCK</h2>
        </div>
        
        <div className="max-w-3xl mx-auto px-4 pt-16">
          <div className="aspect-w-1 aspect-h-1 w-full mb-8">
            <img
              src={getProductImage()}
              alt={product?.title}
              className="w-full h-full object-contain rounded-lg"
            />
          </div>

          <h1 className="text-2xl font-bold text-[#2B2D42] leading-tight mb-4">{product.title}</h1>
          
          <div className="flex items-center gap-2 mb-4">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
              ))}
            </div>
            <span className="text-sm">(126 Reviews)</span>
          </div>

          <div className="flex items-center gap-3 mb-2">
            <span className="text-gray-500 line-through text-lg">€{originalPrice.toFixed(2)}</span>
            <span className="text-2xl font-bold">€{adjustedPrice.toFixed(2)}</span>
            <span className="bg-[#1f2337] text-white px-4 py-1 rounded-full text-sm font-bold">
              SAVE {discountPercentage}%
            </span>
          </div>

          <p className="text-gray-600 text-sm mb-6">Tax included.</p>

          <div className="flex items-center gap-2 text-gray-600 text-sm mb-6">
            <span className="text-lg">👁</span>
            <p className="transition-all duration-300">{viewerCount} people watching this product now!</p>
          </div>

          {(isIPhone || isSamsung) && (
            <>
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-4">Color</h3>
                <div className="flex gap-4">
                  {colors.map((color) => (
                    <button
                      key={color.name}
                      onClick={() => setSelectedColor(color.name)}
                      className={`relative w-12 h-12 rounded-full ${color.class} ${
                        selectedColor === color.name 
                          ? 'ring-2 ring-offset-2 ring-[#2B2D42]' 
                          : 'ring-1 ring-gray-200'
                      }`}
                    >
                      <span className="sr-only">{color.name}</span>
                      {selectedColor === color.name && (
                        <span className="absolute inset-0 flex items-center justify-center">
                          <Check className="w-6 h-6 text-white" />
                        </span>
                      )}
                    </button>
                  ))}
                </div>
                <p className="mt-2 text-sm text-gray-500">
                  Selected: {selectedColor}
                  {colors.find(c => c.name === selectedColor)?.price > 0 && (
                    <span className="ml-2 text-[#2B2D42]">
                      (+€{colors.find(c => c.name === selectedColor)?.price.toFixed(2)})
                    </span>
                  )}
                </p>
              </div>

              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-900 mb-4">Storage</h3>
                <div className="grid grid-cols-3 gap-4">
                  {storageOptions.map((storage) => (
                    <button
                      key={storage.size}
                      onClick={() => setSelectedStorage(storage.size)}
                      className={`border-2 rounded-lg py-3 px-4 text-center ${
                        selectedStorage === storage.size
                          ? 'border-[#2B2D42] bg-[#2B2D42] text-white'
                          : 'border-gray-200 hover:border-[#2B2D42]'
                      }`}
                    >
                      {storage.size}
                    </button>
                  ))}
                </div>
                <p className="mt-2 text-sm text-gray-500">
                  Selected: {selectedStorage}
                  {storageOptions.find(s => s.size === selectedStorage)?.price > 0 && (
                    <span className="ml-2 text-[#2B2D42]">
                      (+€{storageOptions.find(s => s.size === selectedStorage)?.price.toFixed(2)})
                    </span>
                  )}
                </p>
              </div>
            </>
          )}

          {sizes.length > 0 && (
            <div className="mb-6">
              <h3 className="text-sm font-medium text-gray-900 mb-4">Size</h3>
              <div className="grid grid-cols-4 gap-4">
                {sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`border-2 rounded-lg py-3 px-4 text-center ${
                      selectedSize === size
                        ? 'border-[#2B2D42] bg-[#2B2D42] text-white'
                        : 'border-gray-200 hover:border-[#2B2D42]'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-sm text-gray-500">
                Selected: {selectedSize}
                {isFragrance && (
                  <span className="ml-2 text-[#2B2D42]">
                    {selectedSize === '100ml' && '(+€10.00)'}
                    {selectedSize === '30ml' && '(-€5.00)'}
                  </span>
                )}
              </p>
              
              {(isMonclerMaya || isBelstaff) && (
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Size Guide</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>XS: 44 EU / 34 US</div>
                    <div>S: 46 EU / 36 US</div>
                    <div>M: 48 EU / 38 US</div>
                    <div>L: 50 EU / 40 US</div>
                    <div>XL: 52 EU / 42 US</div>
                    <div>XXL: 54 EU / 44 US</div>
                    <div>3XL: 56 EU / 46 US</div>
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="mb-6">
            <p className="text-sm mb-2">Quantity</p>
            <div className="inline-flex border-2 border-gray-300 rounded-lg">
              <button 
                onClick={() => quantity > 1 && setQuantity(q => q - 1)}
                className="px-4 py-2"
              >
                −
              </button>
              <input
                type="text"
                value={quantity}
                readOnly
                className="w-16 text-center text-sm border-none focus:ring-0"
              />
              <button 
                onClick={() => quantity < 10 && setQuantity(q => q + 1)}
                className="px-4 py-2"
              >
                +
              </button>
            </div>
          </div>

          <button
            onClick={handleAddToCart}
            className="w-full bg-[#1f2337] text-white py-3 rounded-lg text-lg font-bold tracking-wider mb-6"
          >
            ADD TO CART
          </button>

          <div className="bg-white rounded-lg p-6 shadow-sm mb-6">
            <p className="text-sm mb-3 italic transition-opacity duration-300">
              "{currentReview.text}"
            </p>
            <div className="flex items-center gap-2">
              <p className="text-gray-600 text-sm transition-opacity duration-300">{currentReview.name}</p>
              <div className="flex">
                {[...Array(currentReview.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                ))}
              </div>
            </div>
            <div className="flex justify-center gap-2 mt-4">
              {reviews.map((_, index) => (
                <button 
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    currentTestimonialIndex === index ? 'bg-[#2B2D42]' : 'bg-gray-300'
                  }`}
                  onClick={() => setCurrentTestimonialIndex(index)}
                />
              ))}
            </div>
          </div>

          <div className="flex items-center justify-center gap-2 bg-gray-50 py-4 rounded-lg text-[#2B2D42] text-sm font-medium mb-6">
            <Package className="w-5 h-5" />
            ORDER NOW AND RECEIVE IN 4-8 DAYS
          </div>

          <div className="grid grid-cols-3 gap-6 text-center mb-8">
            <div className="flex flex-col items-center">
              <CheckSquare className="w-8 h-8 mb-2 text-[#2B2D42]" />
              <h3 className="text-lg font-bold text-[#2B2D42]">1:1 Replica</h3>
            </div>
            <div className="flex flex-col items-center">
              <Box className="w-8 h-8 mb-2 text-[#2B2D42]" />
              <h3 className="text-lg font-bold text-[#2B2D42]">Original Packaging</h3>
            </div>
            <div className="flex flex-col items-center">
              <FileText className="w-8 h-8 mb-2 text-[#2B2D42]" />
              <h3 className="text-lg font-bold text-[#2B2D42]">Valid Serial Number</h3>
            </div>
          </div>

          <div className="mb-8 space-y-4">
            {faqs.map((faq) => (
              <div key={faq.id} className="border rounded-lg">
                <button
                  className="w-full px-4 py-3 flex items-center justify-between text-left"
                  onClick={() => toggleFaq(faq.id)}
                >
                  <span className="font-medium text-[#2B2D42]">{faq.question}</span>
                  <ChevronDown className={`w-5 h-5 transition-transform ${
                    expandedFaq === faq.id ? 'transform rotate-180' : ''
                  }`} />
                </button>
                {expandedFaq === faq.id && (
                  <div className="px-4 pb-3 text-gray-600">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="max-w-3xl mx-auto px-4 py-8">
          <h2 className="text-2xl font-bold text-[#2B2D42] mb-8">
            Frequently Bought Together
          </h2>
          
          <div className="space-y-6">
            {frequentlyBought.map((item, index) => (
              item && (
                <div key={item.id} className="flex items-center gap-4">
                  <div className="w-24 h-24">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-contain rounded-lg"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-base font-medium text-[#2B2D42]">{item.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-gray-500 line-through text-sm">€{getOriginalPrice().toFixed(2)}</span>
                      <span className="font-bold">€{item.price.toFixed(2)}</span>
                    </div>
                  </div>
                  {item.variants && item.variants.length > 0 && (
                    <select className="border border-gray-300 rounded px-3 py-1 text-sm">
                      {item.variants.map((variant) => (
                        <option key={variant} value={variant}>{variant}</option>
                      ))}
                    </select>
                  )}
                </div>
              )
            ))}
          </div>

          <div className="mt-8 pt-6 border-t border-gray-200">
            <div className="flex justify-between items-end mb-4">
              <div>
                <div className="text-2xl font-bold text-[#2B2D42]">
                  €{totalDiscountedPrice.toFixed(2)} EUR
                </div>
                <div className="text-gray-500 line-through text-sm">
                  €{totalOriginalPrice.toFixed(2)}
                </div>
              </div>
              <div className="text-right">
                <div className="text-green-600 font-medium">
                  €{totalSavings.toFixed(2)} EUR in savings
                </div>
              </div>
            </div>

            <button
              onClick={handleAddAllToCart}
              className="w-full bg-[#1f2337] text-white py-3 rounded-lg text-lg font-bold hover:bg-[#2a2f45] transition-colors"
            >
              Add all to cart
            </button>
          </div>
        </div>

        <div className="max-w-3xl mx-auto px-4 py-12 bg-gray-50">
          <h2 className="text-2xl font-bold text-[#2B2D42] text-center mb-12">
            Why Resell-Mansion?
          </h2>
          
          <div className="bg-white rounded-xl shadow-sm overflow-hidden">
            <div className="grid grid-cols-3 text-center border-b">
              <div className="p-4 font-bold text-lg bg-[#1f2337] text-white">
                Features
              </div>
              <div className="p-4 font-bold text-lg text-[#2B2D42]">
                Resell-Mansion
              </div>
              <div className="p-4 font-bold text-lg text-[#2B2D42]">
                Others
              </div>
            </div>

            <div className="divide-y">
              <div className="grid grid-cols-3 items-center">
                <div className="p-4 font-medium bg-gray-50">Fast Shipping</div>
                <div className="p-4 flex justify-center">
                  <Check className="w-6 h-6 text-green-500" />
                </div>
                <div className="p-4 flex justify-center">
                  <X className="w-6 h-6 text-red-500" />
                </div>
              </div>

              <div className="grid grid-cols-3 items-center">
                <div className="p-4 font-medium bg-gray-50">Top Quality</div>
                <div className="p-4 flex justify-center">
                  <Check className="w-6 h-6 text-green-500" />
                </div>
                <div className="p-4 flex justify-center">
                  <X className="w-6 h-6 text-red-500" />
                </div>
              </div>

              <div className="grid grid-cols-3 items-center">
                <div className="p-4 font-medium bg-gray-50">Secure Payments</div>
                <div className="p-4 flex justify-center">
                  <Check className="w-6 h-6 text-green-500" />
                </div>
                <div className="p-4 flex justify-center">
                  <X className="w-6 h-6 text-red-500" />
                </div>
              </div>

              <div className="grid grid-cols-3 items-center">
                <div className="p-4 font-medium bg-gray-50">24/7 Support</div>
                <div className="p-4 flex justify-center">
                  <Check className="w-6 h-6 text-green-500" />
                </div>
                <div className="p-4 flex justify-center">
                  <X className="w-6 h-6 text-red-500" />
                </div>
              </div>

              <div className="grid grid-cols-3 items-center">
                <div className="p-4 font-medium bg-gray-50">Money-Back Guarantee</div>
                <div className="p-4 flex justify-center">
                  <Check className="w-6 h-6 text-green-500" />
                </div>
                <div className="p-4 flex justify-center">
                  <X className="w-6 h-6 text-red-500" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <WhyChooseUs />
      </div>
    </div>
  );
}