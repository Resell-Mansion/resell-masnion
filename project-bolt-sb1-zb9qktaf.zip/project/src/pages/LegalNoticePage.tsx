import React, { useEffect } from 'react';

export default function LegalNoticePage() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
        <div className="border-t border-gray-200"></div>
      </div>
      
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-4xl sm:text-5xl font-bold text-[#2B2D42] text-center mb-8">Legal Notice (Impressum)</h1>
        
        <div className="space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">Company Information</h2>
            <div className="text-gray-600 leading-relaxed">
              <p>Resell Mansion</p>
              <p>Hauptstraße 32</p>
              <p>5443 Frankfurt</p>
              <p>Germany</p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">Contact</h2>
            <div className="text-gray-600 leading-relaxed">
              <p>Phone: +49 17846383923</p>
              <p>Email: info@resell-mansion.com</p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">Responsible for Content</h2>
            <p className="text-gray-600 leading-relaxed">
              According to § 55 Abs. 2 RStV, the same contact information as above applies to the person responsible for content.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">EU Dispute Resolution</h2>
            <div className="text-gray-600 leading-relaxed space-y-4">
              <p>
                The European Commission provides a platform for online dispute resolution (OS):{' '}
                <a 
                  href="https://ec.europa.eu/consumers/odr/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-[#2B2D42] underline hover:text-navy-800"
                >
                  https://ec.europa.eu/consumers/odr/
                </a>
              </p>
              <p>
                We are not obliged and not willing to participate in dispute resolution proceedings before a consumer arbitration board.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">Liability for Content</h2>
            <p className="text-gray-600 leading-relaxed">
              As a service provider, we are responsible for our own content on these pages according to Sec. 7, paragraph 1 German Telemedia Act (TMG). 
              According to Sec. 8 to 10 German Telemedia Act (TMG), we are not obligated to monitor transmitted or stored information of third parties 
              or investigate circumstances pointing to illegal activity.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">Liability for Links</h2>
            <p className="text-gray-600 leading-relaxed">
              Our offer includes links to external third-party websites. We have no influence on the contents of those websites, 
              therefore we cannot guarantee for those contents. Providers or administrators of linked websites are always responsible 
              for their own contents.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#2B2D42] mb-4">Copyright</h2>
            <p className="text-gray-600 leading-relaxed">
              The contents and works on these pages created by the site operators are subject to German copyright law. 
              Duplication, processing, distribution, or any form of commercialization of such material beyond the scope 
              of the copyright law shall require the prior written consent of its respective author or creator.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}